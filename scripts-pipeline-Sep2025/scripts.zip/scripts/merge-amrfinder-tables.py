#!/usr/bin/env python3

import pandas as pd
import os
import glob
import csv

extension = ".amrfinder.contig_covs.tsv"

for filename in glob.glob("*.amrfinder.contig_covs.tsv"):
	with open(filename) as test_file:
		dialect = csv.Sniffer().sniff(test_file.read())
		if dialect.delimiter == "\t": d = "tab-delimited"
		elif dialect.delimiter == ",": d = "comma-delimited"
		else: d = "neither tab nor comma delimited" 
		print(filename,d)

dfs = [pd.read_csv(f, index_col=0, dtype={1:'string'}, sep="\t")
       for f in os.listdir(os.getcwd()) if f.endswith(extension)]

merged = pd.concat(dfs, sort=False)

merged.to_csv("amrfinder-contig-cov-merged.csv")
