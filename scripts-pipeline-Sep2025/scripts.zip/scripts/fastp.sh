#! /bin/bash

FORWARD=$1
REVERSE=$2

QCREADS_PATH="qc_reads"
ADAPTERS="scripts/truseq_adapters.fa"
PHIX="scripts/phix174.fa.gz"

# qc reads with bbduk and fastp
source activate base
conda activate bbtools
sample=$(basename $FORWARD _L001_R1_001.fastq.gz)
bbduk.sh -Xmx10g ziplevel=9 threads=16 qin=33 ref=$ADAPTERS in1=$FORWARD in2=$REVERSE out=${sample}.interleaved.atrim.fq.gz stats=${sample}.adapter_stats.txt ftm=5 ktrim=r k=23 mink=9 rcomp=t hdist=2 tbo tpe minlength=0 2>${sample}.adapters.log
bbduk.sh -Xmx10g threads=16 qin=33 interleaved=t ref=$PHIX in=${sample}.interleaved.atrim.fq.gz out=${sample}.interleaved.atrim.nophix.fq.gz outm=${sample}.phix.fq.gz k=31 hdist=1 mcf=0.9 stats=${sample}.phix_stats.txt 2>${sample}.phix.log
fastp --thread 12 --cut_front --cut_window_size 8 --cut_mean_quality 28 --interleaved_in -i ${sample}.interleaved.atrim.nophix.fq.gz -h ${sample}.fastp.html -j ${sample}.fastp.json --out1 ${sample}.forward.atrim.nophix.fastp.fq.gz --out2 ${sample}.reverse.atrim.nophix.fastp.fq.gz

# delete intermediate files
rm *.atrim.fq.gz
rm *.atrim.nophix.fq.gz
rm *.phix.fq.gz

# move other files to qc_reads
mkdir -p $QCREADS_PATH
mv *.html "$QCREADS_PATH"/
mv *.json "$QCREADS_PATH"/
mv *.log "$QCREADS_PATH"/
mv *.txt "$QCREADS_PATH"/