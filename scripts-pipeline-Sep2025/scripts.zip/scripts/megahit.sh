#! /bin/bash

FORWARD=$1
REVERSE=$2

# assembly with Megahit
source activate base
conda activate megahit
ASS=$(basename $FORWARD .forward.atrim.nophix.fastp.fq.gz)
echo "writing assembly to" "$ASS"_megahit
# no singles
megahit -t 12 -m 0.9 -1 $FORWARD -2 $REVERSE --out-prefix $ASS --out-dir "$ASS"_megahit --min-contig-len 400 --k-min 27 --k-max 151 --k-step 4