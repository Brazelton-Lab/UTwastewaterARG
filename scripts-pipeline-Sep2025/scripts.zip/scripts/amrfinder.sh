#! /bin/bash

FAA=$1
DB=$2

source activate base
conda activate amrfinder

BASE=$(basename $FAA .faa)
amrfinder --protein $FAA --plus --database ${DB} -o ${BASE}.amrfinder.tsv --threads 12 2> amrfinder-log-${BASE}.txt
