#! /bin/bash

SCRIPTS_PATH="scripts"
GFF_PATH="gff_files"
AMR_PATH="amrfinder_results"

AMR=$1
ASS=$2
FORWARD=$3
REVERSE=$4

# get contig coverages with coverm
source activate base
conda activate coverm
BASE=$(basename $AMR .amrfinder.tsv)
coverm contig -1 $FORWARD -2 $REVERSE -m tpm -r $ASS -o "$BASE".coverm.tsv -t 12 -v

conda activate pandas
"$SCRIPTS_PATH"/amrfinder-contig-covs.py -a $AMR -c "$BASE".coverm.tsv

# clean up files
mkdir -p "$GFF_PATH"
mv $ASS "$GFF_PATH"/$ASS
mv $BASE-old-names-new-names.tsv "$GFF_PATH"/$BASE-old-names-new-names.tsv
mv $BASE.faa "$GFF_PATH"/$BASE.faa
mv $BASE.gff "$GFF_PATH"/$BASE.gff
mv $BASE.ffn "$GFF_PATH"/$BASE.ffn

mkdir -p "$AMR_PATH"
mv $AMR "$AMR_PATH"/
mv $BASE.coverm.tsv "$AMR_PATH"/
mv amrfinder-log-${BASE}.txt "$AMR_PATH"/