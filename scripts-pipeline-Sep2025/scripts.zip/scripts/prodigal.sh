#! /bin/bash

ASS=$1

# rename contigs
source activate base
conda activate bioawk
BASE=$(basename $ASS .fa)
bioawk -c fastx '{ print ">scaffold-" ++i"_"length($seq)"\n"$seq }' < $ASS > "$BASE".renamed.fa
paste <(grep ">" $ASS) <(grep ">" "$BASE".renamed.fa) | sed 's/>//g' > "$BASE"-old-names-new-names.tsv

# prodigal and cleanup
conda activate prodigal
prodigal -q -p meta -f gff -i $BASE.renamed.fa -o $BASE.gff -a $BASE.faa -d $BASE.ffn 
awk '/^>/{split($0, a, " "); print a[1]; next} {gsub(/[-\*_\.]/,""); print}' $BASE.faa > $BASE.faa.clean
sed -i 's/\x0//g' $BASE.faa.clean
mv $BASE.faa.clean $BASE.faa
awk -F'\t' '/^#/{print $0; next} {sub(/ID\=[^_]*_/, "ID="$1"_", $9); print $1"\t"$2"\t"$3"\t"$4"\t"$5"\t"$6"\t"$7"\t"$8"\t"$9}' $BASE.gff > $BASE.gff.clean
mv $BASE.gff.clean $BASE.gff
