# for each .json file in working directory
# reports number of reads before and after fastp 

with open("fastp-summary.csv", 'w') as o:
	o.write("filename,before_filtering_total_reads,before_filtering_total_bases,before_filtering_read1_total_reads,before_filtering_read2_total_reads,after_filtering_total_reads,after_filtering_total_bases,after_filtering_read1_total_reads,after_filtering_read2_total_reads,low_quality_total_reads,too_many_N_total_reads,too_short_total_reads,duplicated_reads,adapter_trimmed_reads,adapter_trimmed_bases\n")

	import json
	import glob
	for filename in glob.glob("*.json"):
		print(filename)
		with open(filename) as f:
			j = json.load(f)
			pre_total_reads = j["summary"]["before_filtering"]["total_reads"]
			pre_total_bases = j["summary"]["before_filtering"]["total_bases"]

			post_total_reads = j["summary"]["after_filtering"]["total_reads"]
			post_total_bases = j["summary"]["after_filtering"]["total_bases"]

			low_q_reads = j["filtering_result"]["low_quality_reads"]
			too_many_N_reads = j["filtering_result"]["too_many_N_reads"]
			too_short_reads = j["filtering_result"]["too_short_reads"]

			dupes = j["duplication"]["rate"]
			adapter_trimmed_reads = j["adapter_cutting"]["adapter_trimmed_reads"]
			adapter_trimmed_bases = j["adapter_cutting"]["adapter_trimmed_bases"]
			
			pre_read1_reads = j["read1_before_filtering"]["total_reads"]
			pre_read2_reads = j["read2_before_filtering"]["total_reads"]

			post_read1_reads = j["read1_after_filtering"]["total_reads"]
			post_read2_reads = j["read2_after_filtering"]["total_reads"]
		o.write(','.join(map(str, [filename,pre_total_reads,pre_total_bases,pre_read1_reads,pre_read2_reads,post_total_reads,post_total_bases,post_read1_reads,post_read2_reads,low_q_reads,too_many_N_reads,too_short_reads,dupes,adapter_trimmed_reads,adapter_trimmed_bases])))
		o.write('\n')